# simple-steam-idler-replit
24/7 Steam ingame time idler with Replit (simple version)

1. Register at https://replit.com/
2. Create a free app
3. Put these repo files to the app you just created
4. Enter your login and password to the `index.js`. Put shared secret code if you have.
5. Run the app.
6. Go to uptimerobot.com. Register, add ne app, enter a link to your replit app, set 5 mins (a free plan)
